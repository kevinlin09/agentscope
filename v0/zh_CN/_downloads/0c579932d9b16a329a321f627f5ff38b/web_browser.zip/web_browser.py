# -*- coding: utf-8 -*-
"""
.. _web-browser-control:

浏览器控制
====================

本节重定向到
`conversation_with_web_browser_agent/README.md
<https://github.com/modelscope/agentscope/tree/v0/examples/conversation_with_web_browser_agent>`_。
"""
